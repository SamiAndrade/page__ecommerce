# page_ecommerce.
Atividade realizada durante o treinamento da fábrica
